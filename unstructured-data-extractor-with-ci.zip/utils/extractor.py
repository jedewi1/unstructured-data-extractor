import spacy
import pdfplumber
from docx import Document

nlp = spacy.load("en_core_web_sm")

def extract_entities(text):
    doc = nlp(text)
    data = {"PERSON": [], "ORG": [], "GPE": [], "DATE": [], "MONEY": []}
    for ent in doc.ents:
        if ent.label_ in data:
            data[ent.label_].append(ent.text)
    return data

def read_txt(filepath):
    with open(filepath, "r") as f:
        return f.read()

def read_pdf(filepath):
    with pdfplumber.open(filepath) as pdf:
        return "\n".join([page.extract_text() for page in pdf.pages if page.extract_text()])

def read_docx(filepath):
    doc = Document(filepath)
    return "\n".join([para.text for para in doc.paragraphs])

def read_chat(chat_lines):
    return "\n".join(chat_lines)

def read_email(filepath):
    from email import policy
    from email.parser import BytesParser
    with open(filepath, 'rb') as f:
        msg = BytesParser(policy=policy.default).parse(f)
    return msg.get_body(preferencelist=('plain')).get_content()
