import os
import json
from utils.extractor import extract_entities, read_txt, read_pdf, read_docx, read_chat, read_email

def process_file(filepath):
    if filepath.endswith(".txt"):
        return read_txt(filepath)
    elif filepath.endswith(".pdf"):
        return read_pdf(filepath)
    elif filepath.endswith(".docx"):
        return read_docx(filepath)
    elif filepath.endswith(".eml"):
        return read_email(filepath)
    elif filepath.endswith(".chat"):
        with open(filepath) as f:
            return read_chat(f.readlines())
    else:
        raise ValueError("Unsupported file type")

if __name__ == "__main__":
    files = os.listdir("data")
    all_results = {}
    for file in files:
        full_path = os.path.join("data", file)
        try:
            text = process_file(full_path)
            result = extract_entities(text)
            all_results[file] = result
        except Exception as e:
            all_results[file] = {"error": str(e)}

    with open("output/extracted_data.json", "w") as f:
        json.dump(all_results, f, indent=2)

    print("Extraction complete. See output/extracted_data.json")
