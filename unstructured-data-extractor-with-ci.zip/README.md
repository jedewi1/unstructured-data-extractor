# Unstructured Data Extractor

This Python utility extracts structured data from unstructured sources like `.txt`, `.pdf`, `.docx`, email content, and chat transcripts.

## Features
- Named Entity Recognition (NER) using spaCy
- Multi-format support: TXT, PDF, DOCX, email (.eml), chat logs

## How to Run

```bash
pip install -r requirements.txt
python main.py
```
